pulse
=====

Master thesis: Android-based implementation of Eulerian Video Magnification for vital signs monitoring